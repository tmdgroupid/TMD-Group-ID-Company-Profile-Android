package com.ptmediapengembanganteknologiindonesiajaya.tmdgroupid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
